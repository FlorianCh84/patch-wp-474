<?Php
/*
Plugin Name: Patch 474
Plugin URI: https://florianchambolle.fr
Description: Patch pour la version 4.4.7.
Version: 1.0
Author: Florian Chambolle
Author URI: https://florianchambolle.fr
*/

add_filter( 'wp_mail_from', 'baw_fix_wp_474_mail_reset_vulnerability' );
function baw_fix_wp_474_mail_reset_vulnerability( $from_email ) {
	return 'postmaster@florianchambolle.fr';
}